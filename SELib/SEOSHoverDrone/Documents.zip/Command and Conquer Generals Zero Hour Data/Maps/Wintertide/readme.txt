Wintertide

Author: GB

Map Size: 500 x 500

# Players: 4

The beautiful winter landscape of this map is characterized by its sleepy villages and isolated farmhouses. This map provides everything for exciting battles on long winter evenings.



 