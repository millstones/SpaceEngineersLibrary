Red Tide Rising
A Single Player Mission Map, for Zero Hour
created by spyVspy

In this mission you will defend your homeland against an invasion by sea.  The enemy has amassed a powerful invasion force offshore, and your coastal defenses are preparing for the coming onslaught.  You enter the battle just as the first enemy units hit the beaches.
Details: This is a China verses China mission.  You will play as original China, but the enemy will have units from China Infantry and China Tank General.  There are two battleships offshore which will fire at you occasionally. They are indestructible, so don't bother trying to sink them.  You will win when every enemy unit on your land has been destroyed, if you don't get a victory screen, look around for the odd infantry or landing craft and take them out.
spyvspy@ix.netcom.com
