Command & Conquer Generals: Zero Hour Maps

Name: Hot Snow

Author: JCantanero

Description: Hot Snow is an 8-player map set in 3 climates with the upper portion being desert and the lower is snow. The mid section has some tech buildings and supply piles for extra resources. It is better that you play this map 4 vs. 4 and play as allies. 

Installation: 
 Put this into My Documents\Command and Conquer Generals Zero Hour Data\Maps

Thanks to cnclabs for helping me in modifying my previous map