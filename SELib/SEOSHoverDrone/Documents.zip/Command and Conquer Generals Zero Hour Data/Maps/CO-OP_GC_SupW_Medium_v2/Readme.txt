Map name: CO-OP_GC_SupW_Medium_v2
Author: Sriracha
Date: 2021-02-12
E-mail: jonathan16153@hotmail.com

Game: Command & Conquer Generals Zero Hour


Description:

This is a custom generals challenge Co-op map made for 2 players. You will face the superweapon general with a fully built base,
so be prepared.


Difficulty: Medium


About the map:

- This is an online 2-player custom generals challenge map against the superweapon general, General Alexander.
  
- Choosing a Skirmish AI as a teammate will not work, the AI won't do anything. Good idea if you want to play it alone though.

- The map checks for playing players in the upper three slots in the game options (where you set up the game, like choosing map etc).

- This means that the hosting player can be an observer while the two other slots are used by players who will play the map.

- Both playing players should be in the same team. Otherwise the game will end if one of the players is defeated.

- If the two playing players are in the same team, the game will be lost when both players are defeated.

- Experience for generals rank will be received, however you won't be able to see you progess in the experience bar.
  This map gives you the amount of experience of a non-veterancy typeof a certain unit that is destroyed by scripts. 
  The experience will be given to both players. For example, If player 1 destroys a raptor, player 1 and player 2
  will receive the same amount of experience for destroying that raptor.

- Sadly, the player units won´t receive veterancy.

- The colour of the AI opponent is purple.

- The map.ini only contains modification for the water texture. The game can be played directly after transfer.

- Recommended starting cash at least 20k.

- To conclude: The two players who will play the map needs to be in two of the upper three slots in the game options.
  They should be in the same team. The game will be lost if both players are defeated. A host can be an observer.
  You will receive shared experience for destroying units but it cannot be seen
  on the experience bar. Your units won't be able to receive veterancy.
  The colour of the AI opponent is purple.
  No need to restart the game to play the map.
  Recommended starting cash at least 20k.


The map has been tested and beaten.
If you find any bugs, you're welcome to report it to me by e-mail.
  

A final note: Expect surprises...

have fun!


Sriracha 
2021-02-12