MapName: Battle Ring
Author: AnthraxPanda
E-Mail: sewot@sbk-home.de
Max. Players: 8; Skirmish Map
Game: C&C Generals Zero Hour
_________________________________________________________________
This is my 10th and last map for my Map Package, so I wanted to do something special.
A Concrete Arena surrounded with Lava and 8 players fighting for their lifes. Get as many
supplys from the Ring as possible!
