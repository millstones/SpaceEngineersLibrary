The Gauntlet
___________________________________________________________________________
created by spyVspy

A single player mission for Generals Zero Hour
(playing as USA and China, verses GLA and China enemies)


An insurgent army has overrun the small island province of a southeast Asian country.  You have been called in to counter this rebellion.  Your task force is assembled at an airstrip, and must convoy through hostile territory to engage the rebel base.  In-game briefings will tell you how to proceed.  

You cannot build a base and must complete the mission with the given assets.  You will receive some reinforcements and can build USA infantry.

If your forces fall below a threshold of 5 vehicles the mission will be aborted, and you will lose and have to start again.


Hints:
- Recon thoroughly before moving.
- Repair your units when you can.
- Use your General's promotions.
- Make full use of your infantry.


Special Thanks go to Deathstrike and the G.o.a.T for their assistance.

spyvspy@ix.netcom.com
