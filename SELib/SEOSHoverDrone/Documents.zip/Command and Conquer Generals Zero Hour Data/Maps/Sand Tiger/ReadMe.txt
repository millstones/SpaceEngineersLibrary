This is my second map and maybe you've noticed I played
a little bit with some more scripts to see how they work.
The whole point was to make it feel alive as I've found
the game's maps and especially multiplayer maps to be very
rarely entertaining enough. So I added some spice.

Mainly I decided to add some lore to the maps to make them
a little interesting.

Some more details:
I've tested the map and it's a test of feedback, there's
5 lanes than the usual 3, they are even, a little
cramped for stealth and very tricky. The basic psychology would
make you go through the middle of the map.
The left side is better on defense than the side on the
right even if it looks like the rightmost teams are more
inclined for turtling. 

Here's how the map was designed:
Right side: near blind on the top but better movement
Left side: not enough movement, more defense and weak 
bottom
Center: cramped to break the stalemate
Objectives: Something to fight for.
Total worktime: 3 days 

All platforms have a total of 30.000$ to push players.
Turtling without microing will result in defeat due to
cramping in the middle. You essentially need the supplies.
Otherwise if you decide to turtle, you let them to the 
enemy and the flanks + 30k bonus credits to the enemy will
crush you. This also makes the importance of teamwork imperative
as only one or two at best can have the middle resources. 

The players on top will have to fight for oil derricks
or lose their base as the oils are nearly not that easily
defended to not make it unfair for campers in buildings.
Which makes their defense a waste of money as the 
roads allow for toxin tractors or dragon tanks or rangers
with flashbangs to easily manouver through.

The space between allies is made for easy reinforcement by
even swarming if necessary.
Since there is a new GLA rush technique and players 
struggle to play GLA effectively, the dozer easter egg
will help with that if anyone knows it as GLA has the best
chance to get it all the time and increase the challenge
of the game in general.

Have fun and I hope you enjoy it. For feedback you can
write on the youtube video of the map preview linked
in description of the map. I've got notes now 
about player feedback and I'm waiting to see
what people want out of these maps for 
optimal play.


Made by Kennops at https://www.twitch.tv/kennops

