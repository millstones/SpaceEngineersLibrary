Made By MTR

ParadiseInRuins - 3 player medium map situated some place in the southeast.

Free for All or whichever you prefer.