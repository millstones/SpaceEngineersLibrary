Terra Deserta
Author: GB

Map Size: 500 x 500

# Players: 4

The afternoon sun beats down mercilessly on this scenic desert landscape with its small towns and scattered farms. The heat is stifling and no wind brings relief, the people seek shelter in their houses. 