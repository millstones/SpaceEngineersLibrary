//This file contains some of the text located on the cncLabs download page - find the latest and best community maps there, at cnclabs.com//

Greetings Earthlings. Before you is the Readme for v2 of Hell on Rails, created by Newgate. 

As the crimson sun disappears below the horizon, thousands of fireflies rise from the rough land as it is lit on fire in colours of red and yellow. Beside the worn rails, giant mushrooms grow rampant and sounds of the active railway turntable filter through trees like none seen before. Once the hub of an expanding railway empire, this narrow valley provides the means for some very interesting games.


This map is designed for 2v2 games with one main supply for each player as well as one safe supply between the teammates. The wide-open space in the middle holds two clusters of supply piles and four oils. 



This map was my only submission to Dominator's 2020 World Builder Contest!
Don't go looking for v1, only the guardians of Game Replays know of its whereabouts... as well as all the people on our Discord Server! If you're looking to learn, share or gawp at people's maps, there's no better place in the multiverse to do so. Links are below.

CnC ZH Worldbuilders' Discord:
https://discord.gg/tJ6zyGb

------To Contact me------

My email address is: NewgateM17@Gmail.com
or get a quick reply on Discord: @Newgate#0636

You may take any code you need, provided that you credit me.
You may not re-upload this map under your name or without credit.

Corporate thanks you for downloading the map. Share and enjoy!



P.S.
The bomb trucks can do some funky things on this map