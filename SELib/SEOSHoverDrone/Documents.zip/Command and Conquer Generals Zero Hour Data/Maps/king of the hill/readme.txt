King of the Hill

Author: GB

Map Size: 600 x 600

# Players: 7


The marvelous winter landscape of this map is characterized by its wide plains, lakes and forests and small hills and its isolated farmhouses and tiny villages.

A unique fighting position is placed at the center of the map and which is equipped with additional resources and artillery platforms. Best conditions to defend this position against up to 6 attackers.



 